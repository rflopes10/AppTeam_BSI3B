import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RecursosHumanosPage } from './recursos-humanos';

@NgModule({
  declarations: [
    RecursosHumanosPage,
  ],
  imports: [
    IonicPageModule.forChild(RecursosHumanosPage),
  ],
})
export class RecursosHumanosPageModule {}
